def Update(self):
        if(self.play & (time.time()-self.start >= self.playBackSpeed)):
            self.start = time.time()
            self.frame = min(self.frame + 1, self.frameMax-1)
            if self.frame == self.frameMax-1: